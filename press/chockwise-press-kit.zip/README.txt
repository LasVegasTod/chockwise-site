Chockwise press kit
https://chockwise.com/press

logos/   the logos and icons on chockwise.com now. [LOGO files]: the final pack (SVG and PNG, light and
         dark, with usage notes) is to come; these are site icons, pending the final logo pack.
images/  product shot, social card
chockwise-fact-sheet.txt  boilerplates, short bio, media contact

Still to come: [LOGO files], [HEADSHOT], [BUSIEST GATES CHART]

Images are free to use with credit "Chockwise".
Questions: info@chockwise.com
